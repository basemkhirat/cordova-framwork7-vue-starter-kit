<template>

    <div data-page="home" class="page">

        <div class="navbar">
            <div class="navbar-inner">
                <div class="left">
                    <a href="#" class="link icon-only open-panel" data-panel="left">
                        <i class="icon f7-icons">menu</i>
                    </a>
                </div>
                <div class="center">My APP</div>
                <div class="right"></div>
            </div>
        </div>

        <div class="page-content">
            <div class="content-block">
                <p>
                    <a class="button button-fill open-popup" data-popup="#popup">Open popup</a>
                </p>
                <p>
                    <a class="button button-fill" href="/login">Login</a>
                </p>
            </div>
        </div>

        <div class="toolbar toolbar-bottom toolbar-fixed">
            <div class="toolbar-inner">
                <a href="#" class="link">1</a>
                <a href="#" class="link">2</a>
                <a href="#" class="link">3</a>
                <a href="#" class="link">4</a>
            </div>
        </div>

    </div>



</template>


<script>

    export default {

        methods: {

            onF7Init: function () {

                console.log("Home init")

                const base = this;

                console.log(base.$device);

                console.log(base.$$);

                console.log(base.$theme);

                console.log(base.$f7);

//                base.$f7.addNotification({
//                    title: 'Framework7',
//                    message: 'welcome',
//                    button: {
//                        text: 'Close Me',
//                        color: 'lightgreen'
//                    },
//                    onClose: function () {
//                        base.$f7.alert('Notification closed');
//                    }
//                });

            }

        },


    }

</script>
