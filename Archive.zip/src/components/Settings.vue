<template>

    <div id="settings">

        <div class="navbar">
            <div class="navbar-inner">
                <div class="left">
                    <a href="#" class="link icon-only" @click="$router.back()">
                        <i class="icon f7-icons">arrow-left</i>
                    </a>

                </div>
                <div class="center">
                    Settings
                </div>
                <div class="right"></div>
            </div>
        </div>

        <div data-page="settings" class="page">
            <div class="page-content">
                settings
            </div>
        </div>

    </div>

</template>


<script>

    export default {

        methods: {

            onF7Init: function () {
                console.log("Settings init")
            }

        }

    }

</script>
