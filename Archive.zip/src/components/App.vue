<template>

    <div id="app">

        <!-- Status bar Overlay -->
        <div class="statusbar-overlay"></div>

        <!-- Panels Overlay -->
        <div class="panel-overlay"></div>

        <!-- Main App -->

        <f7-views>
            <f7-view main>
                <f7-pages navbar-through toolbar-fixed>
                    <home></home>
                </f7-pages>
            </f7-view>
        </f7-views>

        <!-- Left panel -->

        <div class="panel panel-left panel-cover navbar-fixed">

            <div class="navbar">
                <div class="navbar-inner">
                    <div class="left">
                        <a href="#" class="link">Left Menu</a>
                    </div>
                </div>
            </div>

            <div class="page">

                <div class="page-content">

                    <div class="list-block">
                        <ul>

                            <li class="item-content">
                                <div class="item-media"><i class="icon icon-f7"></i></div>
                                <div class="item-inner">
                                    <div class="item-title">
                                        <a href="/home" class="close-panel" data-view=".view-main">News Feed</a>
                                    </div>
                                    <div class="item-after"><span class="badge">5</span></div>
                                </div>
                            </li>

                            <li class="item-content">
                                <div class="item-media"><i class="icon icon-f7"></i></div>
                                <div class="item-inner">
                                    <div class="item-title">
                                        <a href="/settings" class="close-panel" data-view=".view-main">Settings</a>

                                    </div>

                                </div>
                            </li>

                            <li class="item-content">
                                <div class="item-media"><i class="icon icon-f7"></i></div>
                                <div class="item-inner">
                                    <div class="item-title">
                                        <a href="/login" class="close-panel" data-view=".view-main">Login</a>
                                    </div>
                                </div>
                            </li>

                        </ul>
                    </div>

                </div>

            </div>

        </div>

        <!-- popup -->

        <div class="popup tablet-fullscreen navbar-fixed" id="popup">

            <div class="navbar">
                <div class="navbar-inner">
                    <div class="left">
                        <a href="#" class="link">Left Menu</a>
                    </div>

                    <div class="right close-popup">
                        <a href="#" class="link close-popup">
                            Close
                        </a>
                    </div>
                </div>
            </div>

            <div class="page">

                <div class="page-content">

                    <div class="content-block">
                        ddddd
                    </div>

                </div>

            </div>


        </div>


    </div>
</template>


<script>

    import Home from './Home.vue';

    export default {

        methods: {

            onF7Init: function () {
                console.log("App init")
            }


        },

        components: {
            'home': Home
        }

    }

</script>
