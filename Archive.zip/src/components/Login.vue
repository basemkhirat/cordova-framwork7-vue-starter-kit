<template>

    <div id="login">

        <div data-page="login" class="page">

            <!-- page-content has additional login-screen content -->

            <div class="page-content login-screen-content">

                <div class="login-screen-title">

                    <a href="#home">My App</a>

                </div>

                <!-- Login form -->

                <form @submit.prevent="login">

                    <div class="list-block">

                        <ul>

                            <li>
                                <div class="item-content">
                                    <div class="item-media"><i class="icon f7-icons">person</i></div>
                                    <div class="item-inner">
                                        <div class="item-title label">Email</div>
                                        <div class="item-input">
                                            <input type="email" placeholder="Your Email">
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li>
                                <div class="item-content">
                                    <div class="item-media"><i class="icon f7-icons">lock</i></div>
                                    <div class="item-inner">
                                        <div class="item-title label">Password</div>
                                        <div class="item-input">
                                            <input type="password" placeholder="Your Password">
                                        </div>
                                    </div>
                                </div>
                            </li>

                        </ul>

                        <f7-block>
                            <button style="width: 100%" type="submit" :disabled="false"
                                    class="button button-big button-fill"
                                    color="blue">Login
                            </button>

                            <br/>

                            <a href="/register" class="button button-big">Register a new account</a>
                        </f7-block>

                    </div>

                </form>

            </div>

        </div>

    </div>


</template>


<script>

    export default {

        methods: {

            onF7Init: function () {
                console.log("Login init")
            },

            login: function () {

                const base = this.$f7;

                base.alert("Signing In..", function () {
                    location.href = "/";
                });
            }

        }

    }

</script>
