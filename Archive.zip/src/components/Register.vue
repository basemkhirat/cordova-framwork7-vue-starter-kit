<template>

    <div id="register">

        <div data-page="register" class="page">

            <!-- page-content has additional login-screen content -->

            <div class="page-content login-screen-content">

                <div class="login-screen-title">

                    <a href="#home">My App</a>

                </div>

                <!-- Login form -->

                <form @submit.prevent="register">

                    <div class="list-block">

                        <ul>
                            <!-- Name -->

                            <li>
                                <div class="item-content">
                                    <div class="item-media"><i class="icon f7-icons">person</i></div>
                                    <div class="item-inner">

                                        <f7-grid>

                                            <f7-col>
                                                <input type="text" placeholder="First Name">
                                            </f7-col>

                                            <f7-col>
                                                <input type="text" placeholder="Last Name">
                                            </f7-col>

                                        </f7-grid>

                                    </div>
                                </div>
                            </li>

                            <!-- Email -->

                            <li>
                                <div class="item-content">
                                    <div class="item-media"><i class="icon f7-icons">person</i></div>
                                    <div class="item-inner">
                                        <div class="item-title label">Email</div>
                                        <div class="item-input">
                                            <input type="email" placeholder="Your Email">
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <!-- Password -->

                            <li>
                                <div class="item-content">
                                    <div class="item-media"><i class="icon f7-icons">lock</i></div>
                                    <div class="item-inner">
                                        <div class="item-title label">Password</div>
                                        <div class="item-input">
                                            <input type="password" placeholder="Your Password">
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <!-- Confirm Password -->

                            <li>
                                <div class="item-content">
                                    <div class="item-media"><i class="icon f7-icons">lock</i></div>
                                    <div class="item-inner">
                                        <div class="item-title label">Confirm Password</div>
                                        <div class="item-input">
                                            <input type="password" placeholder="Your Password">
                                        </div>
                                    </div>
                                </div>
                            </li>

                        </ul>

                        <f7-block>
                            <button style="width: 100%" type="submit" :disabled="false"
                                    class="button button-big button-fill"
                                    color="blue">Register
                            </button>

                            <br/>

                            <a href="/login" class="button button-big">Have an account ? Sign In</a>

                        </f7-block>

                    </div>

                </form>

            </div>

        </div>

    </div>


</template>

<script>

    export default {

        methods: {

            onF7Init: function () {
                console.log("Login page init")
            },

            register: function () {

                const app = this.$f7;

                this.$f7.alert("Signing Up..", function () {
                    location.href = "/";
                });
            }

        }

    }

</script>
