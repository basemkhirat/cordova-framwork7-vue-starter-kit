// Avaiable themes ['ios', 'material']
const theme = 'ios';

require('framework7');
require('framework7/dist/css/framework7.' + theme + '.min.css');
require('framework7/dist/css/framework7.' + theme + '.colors.min.css');
require('framework7-icons/css/framework7-icons.css');

import Vue from 'vue';
import App from './components/App.vue';
import Framework7Vue from 'framework7-vue';
import VueResource from 'vue-resource';
import VueConfig from "vue-config";
import VueAuth from "./auth";
import Routes from './routes';
import {store} from './store/store';
import {i18n} from "./i18n";

Vue.use(VueConfig, require('./config'));
Vue.use(VueResource);
Vue.use(Framework7Vue);
Vue.use(VueAuth);

new Vue({
    el: '#app',
    render: h => h(App),
    i18n,
    store,
    framework7: {
        root: '#app',
        material: true,
        pushState: true,
        //animateNavBackIcon: true,
        routes: Routes,
        //dynamicNavbar: true,
        swipePanel: 'left',
        //domCache: true,
        modalTitle: 'Project title',
        modalButtonOk: '_ok',
        modalButtonCancel: '_cancel'
    }
});
