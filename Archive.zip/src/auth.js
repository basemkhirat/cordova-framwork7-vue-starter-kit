export default function (Vue) {

    Vue.auth = {

        getToken(){
            let token = localStorage.getItem("token")
            let expiration = localStorage.getItem("expiration")

            if (!token || !expiration) {
                return null
            }

            if (Date.now() > expiration) {
                return null
            }

            return token
        },

        setToken(token, expiration){
            localStorage.setItem("token", token)
            localStorage.setItem("expiration", expiration)
        },

        destroyToken(){
            localStorage.removeItem("token")
            localStorage.removeItem("expiration")
        },

        check(){
            if (this.getToken()) {
                return true
            }
            return false
        },

        attempt(username, password, callback){

            // here we will check username & password from the api and if true => call setuser

            callback(this.user())
        },

        setUser(user){
            localStorage.setItem("user", user)
        },

        user(){
            return localStorage.getItem("user")
        }

    }

    Object.defineProperties(Vue.prototype, {
        $auth: {
            get(){
                return Vue.auth
            }
        }
    })

}
